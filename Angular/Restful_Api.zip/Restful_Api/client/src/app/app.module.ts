import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpService } from './http.service';
import {HttpClientModule} from "@angular/common/http";

import { AppComponent } from './app.component';
import { from } from 'rxjs';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule //import and write here 
  ],
  providers: [HttpService], //import and write here 
  bootstrap: [AppComponent]
})
export class AppModule { }
